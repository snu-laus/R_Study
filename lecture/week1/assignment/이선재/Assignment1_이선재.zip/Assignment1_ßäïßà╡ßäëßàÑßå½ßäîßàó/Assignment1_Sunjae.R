public <- read.csv("public_corporation.csv")
str(public)
names(public) = c("ID", "Cat1", "Cat2", "Cat3", "Name", "Address", "Sido", "Sigungu", "Dong", "Website", "Lat", "Long")
str(public)

pt = data.frame(longitude=public$Long, latitude=public$Lat)
cs1 = CRS("+proj=longlat +datum=WGS84")
cs2 = CRS("+proj=tmerc +lat_0=38 +lon_0=127 +k=1 +x_0=200000 +y_0=600000 +ellps=GRS80 +units=m")

spt = SpatialPoints(pt,proj4string = cs1)
pub = SpatialPointsDataFrame(spt, data=public)
plot(pub, axes=T, pch=19)

pub2 = spTransform(pub, cs2)
plot(pub2, axes=T, pch=19)
print(st_crs(pub2))

public_tm <- st_as_sf(pub2)
st_write(public_tm, dsn = '.', layer="public_tm", driver="ESRI shapefile", layer_options = "ENCODING=UTF-8")

