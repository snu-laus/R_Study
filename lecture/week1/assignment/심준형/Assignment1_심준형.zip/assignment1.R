# 1. 데이터 확인

library(sf)

public <- read.csv("public_corporation.csv", encoding = "UTF-8")

str(public)

names(public) <- c("Key", "C1", "C2", "C3", "Name", "Address", 
                      "Si", "Gu", "Dong", "Page", "Latitude", "Longtitude")

print(names(public))


# 2. 좌표계 변환

cs1 <- st_crs("+proj=longlat +datum=WGS84")

cs2 <- st_crs("+proj=tmerc +lat_0=38 +lon_0=127 +k=1 +x_0=200000 +y_0=600000 +ellps=GRS80 +units=m")

public_tm_before <- st_as_sf(public, coords = c("Longtitude", "Latitude"), crs = cs1)

public_tm <- st_transform(public_tm_before, crs = cs2)

print(st_crs(public_tm))


# 3. 파일 저장 (인코딩 문제로 GPKG로 저장함)

st_write(public_tm, "result.gpkg", driver = "GPKG")
